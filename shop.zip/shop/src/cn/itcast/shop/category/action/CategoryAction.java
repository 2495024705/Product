package cn.itcast.shop.category.action;

public class CategoryAction {

}

package com.rain.dao;

import com.rain.domain.OptometrymessageInfo;

import tk.mybatis.mapper.common.Mapper;

public interface YanguangDao extends Mapper<OptometrymessageInfo>{

}

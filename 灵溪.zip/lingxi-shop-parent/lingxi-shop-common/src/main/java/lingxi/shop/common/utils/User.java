package lingxi.shop.common.utils;

import lombok.Data;

@Data
public class User {
    String name;
    Integer age;
}
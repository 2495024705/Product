package lingxi.shop.item.mapper;

import lingxi.shop.common.BaseMapper.BaseMapper;
import lingxi.shop.item.pojo.Sku;

public interface SkuMapper extends BaseMapper<Sku> {
}

package lingxi.shop.item.mapper;

import lingxi.shop.item.pojo.Spu;
import tk.mybatis.mapper.common.Mapper;

public interface SpuMapper extends Mapper<Spu> {
}

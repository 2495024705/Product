package lingxi.shop.item.mapper;

import lingxi.shop.item.pojo.SpuDetail;
import tk.mybatis.mapper.common.Mapper;

public interface DetailMapper extends Mapper<SpuDetail> {
}

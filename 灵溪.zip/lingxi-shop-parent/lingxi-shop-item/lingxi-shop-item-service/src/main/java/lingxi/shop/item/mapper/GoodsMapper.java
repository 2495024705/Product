package lingxi.shop.item.mapper;

import lingxi.shop.item.pojo.Category;
import lingxi.shop.item.pojo.Spu;
import tk.mybatis.mapper.additional.idlist.IdListMapper;
import tk.mybatis.mapper.common.Mapper;

public interface GoodsMapper extends Mapper<Spu>{
}

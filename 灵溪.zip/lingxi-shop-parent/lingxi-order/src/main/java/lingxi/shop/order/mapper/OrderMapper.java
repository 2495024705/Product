package lingxi.shop.order.mapper;

import lingxi.shop.common.BaseMapper.BaseMapper;
import lingxi.shop.order.pojo.Order;

public interface OrderMapper extends BaseMapper<Order> {
}

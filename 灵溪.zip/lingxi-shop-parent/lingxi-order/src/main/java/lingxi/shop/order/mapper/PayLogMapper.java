package lingxi.shop.order.mapper;

import lingxi.shop.order.pojo.PayLog;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bystander
 * @date 2018/10/5
 */
public interface PayLogMapper extends Mapper<PayLog> {
}
